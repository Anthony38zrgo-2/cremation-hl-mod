========================================================================
       CREMATION MOD & GOLDSRC ENGINE - REPOSITORIO DE DLLs
========================================================================

Este archivo comprimido contiene todas las librerias dinamicas (DLLs)
utilizadas para la ejecucion, intercepcion por proxy e inspeccion
tecnica del mod Cremation y del motor Half-Life 1 (GoldSrc).

------------------------------------------------------------------------
1. MOD CREMATION (Librerias activas de juego y proxy)
------------------------------------------------------------------------
 - Mod_Cremation/dlls/cremation.dll
     Proxy Maestro de Servidor (GameDLL). Intercepta la API de GoldSrc,
     administra oleadas de mansion, IA de zombies (HOTD2 David/Steve/Johnny,
     Randy, Max, Quake Zombie, CZero), combate, armas personalizadas
     y delega llamadas nativas a hl_ravenholm.dll.
 - Mod_Cremation/dlls/hl_ravenholm.dll
     DLL nativa servidora donante (Ravenholm/HL base). Provee la logica
     base del juego a la cual cremation.dll hace forward / hooking.
 - Mod_Cremation/dlls/hl.dll
     DLL servidora Half-Life estandar empaquetada con el mod.
 - Mod_Cremation/cl_dlls/client.dll
     Proxy Maestro de Cliente. Maneja HUD tactico, radar, sistema de clima
     (niebla roja volumetrica GL y lluvia de sangre), barras de vida de jefes,
     audio dinamico y reenvia a client_ravenholm.dll.
 - Mod_Cremation/cl_dlls/client_ravenholm.dll
     DLL nativa cliente donante (Ravenholm base).
 - Mod_Cremation/build_variants/cremation_validation.dll
     Compilacion de servidor con instrumentacion de pruebas de runtime activa.

------------------------------------------------------------------------
2. MOTOR GOLDSRC / HALF-LIFE 1 (Runtime del motor)
------------------------------------------------------------------------
 - Engine_GoldSrc/hw.dll               : Nucleo del motor grafico Hardware / OpenGL.
 - Engine_GoldSrc/sw.dll               : Nucleo del motor en modo Software render.
 - Engine_GoldSrc/swds.dll             : Motor del servidor dedicado (hlds.exe).
 - Engine_GoldSrc/FileSystem_Stdio.dll : Sistema de archivos virtual (VFS) de GoldSrc.
 - Engine_GoldSrc/SDL2.dll             : Capa de ventana, eventos, raton y teclado.
 - Engine_GoldSrc/vgui.dll / vgui2.dll : Motor de interfaz gráfica de Valve (VGUI 1/2).
 - Engine_GoldSrc/tier0.dll/vstdlib.dll: Librerias base y utilidades de Valve.
 - Engine_GoldSrc/Mss32.dll / a3dapi.dll: Motores de audio Miles Sound y Aureal 3D.
 - Engine_GoldSrc/steam_api.dll        : Capa de integracion con el cliente Steam.
 - Engine_GoldSrc/Core.dll / DemoPlayer.dll / proxy.dll : Soporte de red y demos.

------------------------------------------------------------------------
3. BASE VALVE HALF-LIFE 1 (DLLs originales del juego base)
------------------------------------------------------------------------
 - Base_Valve_HL1/cl_dlls/client.dll      : DLL de cliente original de Valve.
 - Base_Valve_HL1/cl_dlls/GameUI.dll      : Menu e interfaz de usuario de Half-Life.
 - Base_Valve_HL1/cl_dlls/particleman.dll : Gestor de particulas nativo.
 - Base_Valve_HL1/dlls/hl.dll             : DLL de servidor original de Half-Life.
 - Base_Valve_HL1/dlls/Director.dll       : Modo espectador y director de camaras.

========================================================================
TABLA DE ARCHIVOS, TAMANO Y HASHES SHA-256 PARA AUDITORIA:
========================================================================
Mod_Cremation/dlls/cremation.dll              |     840192 bytes | SHA256: 8335a06a4e3dc91cd5360e5be5fb48678f8cf72f45b81274dcf6b5bd5c9b97f3
Mod_Cremation/dlls/hl_ravenholm.dll           |    1266176 bytes | SHA256: 27570e63bd4d7d08543d9c9627c55dbf2d35d8f303ef0ef4d660e242a935cef6
Mod_Cremation/dlls/hl.dll                     |    1266176 bytes | SHA256: 27570e63bd4d7d08543d9c9627c55dbf2d35d8f303ef0ef4d660e242a935cef6
Mod_Cremation/cl_dlls/client.dll              |     239104 bytes | SHA256: 47b018fce8cb50b924f901999278abbaaa4098b14904841d5f06e313119f12c7
Mod_Cremation/cl_dlls/client_ravenholm.dll    |     708096 bytes | SHA256: 11846e29cf5c66b861f72b75e1ced98338f55d03d4fa44125ced0222fc93f6bf
Mod_Cremation/build_variants/cremation_validation.dll |     951808 bytes | SHA256: f4b085ae715b12eda94b5651ad5eed4dadb56d7caa93573c9e7df8cc95f834e6
Engine_GoldSrc/hw.dll                         |    3598176 bytes | SHA256: 9ba9a2db5e07598fd59afa35507a98c86162e4e15b3835177b78c11842cd2295
Engine_GoldSrc/sw.dll                         |    3544928 bytes | SHA256: f1a1bfa6edcb96b5e0260119605bb100cf1602affb60bd7aaf969d4a7d577dd7
Engine_GoldSrc/swds.dll                       |    3544928 bytes | SHA256: 64b6872f9c2875ea7da88eb694a34e6e46f2aac7cb35fb436744f462611c03ae
Engine_GoldSrc/FileSystem_Stdio.dll           |      64352 bytes | SHA256: 07a432b6214c6ea5ea4a988d5c8384d3ab35a531b49fe71c354f3fed5ce9f316
Engine_GoldSrc/tier0.dll                      |     114016 bytes | SHA256: 63005b4f37607a6703eaf5fa2cf62c4a2b1254e3518eaeb77c3f0d5bab9e2e54
Engine_GoldSrc/vstdlib.dll                    |     124768 bytes | SHA256: 9de92d51d0814ac632dbb408bae9566f23aabbc3a11499dcc72cda6efc260af4
Engine_GoldSrc/vgui.dll                       |     416576 bytes | SHA256: 63f6a66e71814e848b7875963b22b2518a49a433110fa9663ffc84f1a78ec475
Engine_GoldSrc/vgui2.dll                      |     176992 bytes | SHA256: 542b0bd369c756b6b7ce080066c0a5f1b818c493591d76830d01b6a5343ab8a1
Engine_GoldSrc/SDL2.dll                       |    2024448 bytes | SHA256: 7a7f96e8e8dd97bed0faecdf12f8b22d09ae6181659c86c94f075453cfa6d5f7
Engine_GoldSrc/steam_api.dll                  |     263080 bytes | SHA256: 1ac139ebad2a653adff5700347274cf9816256eb5d69ae6dc43c4cf9c8532aa7
Engine_GoldSrc/Mss32.dll                      |     446976 bytes | SHA256: 3231d251c8aa4003b3b23196fe849b97c5ea3ac2d3549980e83bceb9078b4cf7
Engine_GoldSrc/a3dapi.dll                     |     211456 bytes | SHA256: f05b2eeb851b174ef2b39c4728687915648ae33780a65cdf7f0c7ce99e6a67af
Engine_GoldSrc/Core.dll                       |     191840 bytes | SHA256: d3e3f269dca9d5cb7ab70849a75a2a07d42276d17ad993953365c0bb1488bacc
Engine_GoldSrc/DemoPlayer.dll                 |      47968 bytes | SHA256: 2da1ac83fd5a12e90d4e6b6382454f9ad4cadf6215e64733ea96bb877aabd8dc
Engine_GoldSrc/proxy.dll                      |     184672 bytes | SHA256: a4b09bc7ed1564dceb106ab7ee6307c5effe415b6715e1a882637136e12ee4ae
Base_Valve_HL1/cl_dlls/GameUI.dll             |     850784 bytes | SHA256: b9b8c0c36bd19681627001c06ce2a15496da06b72315d561a12a3964e0265811
Base_Valve_HL1/cl_dlls/particleman.dll        |      27136 bytes | SHA256: ada6fe7263d98a981a2e3f606b30013a93e39148c086b1394ea8aa0c22595232
Base_Valve_HL1/cl_dlls/client.dll             |     643424 bytes | SHA256: e9827e3fe884b72da897c48b9921feb93660f9b0be62bd772e0104ab8c7135f8
Base_Valve_HL1/dlls/Director.dll              |      44896 bytes | SHA256: b5c6bfe69aa1104f2ab0ffb48066a29d300296ef5020ca592397687fb58ad89f
Base_Valve_HL1/dlls/hl.dll                    |     976224 bytes | SHA256: d932d274061ee05bef89ea712f9b32b8f5f742ad0124d5f516c8cca1e421ca24
